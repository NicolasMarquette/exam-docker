#!/bin/bash

# la construction des images se fait avec le docker-compose
# lancement du docker-compose
docker-compose up